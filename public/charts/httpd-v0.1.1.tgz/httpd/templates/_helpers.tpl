{{/*
Expand the name of the chart.
*/}}
{{- define "httpd.name" -}}
{{- default .Chart.Name .Values.nameOverride | trunc 63 | trimSuffix "-" }}
{{- end }}

{{/*
Create a default fully qualified app name.
We truncate at 63 chars because some Kubernetes name fields are limited to this (by the DNS naming spec).
If release name contains chart name it will be used as a full name.
*/}}
{{- define "httpd.fullname" -}}
{{- if .Values.fullnameOverride }}
{{- .Values.fullnameOverride | trunc 63 | trimSuffix "-" }}
{{- else }}
{{- $name := default .Chart.Name .Values.nameOverride }}
{{- if contains $name .Release.Name }}
{{- .Release.Name | trunc 63 | trimSuffix "-" }}
{{- else }}
{{- printf "%s-%s" .Release.Name $name | trunc 63 | trimSuffix "-" }}
{{- end }}
{{- end }}
{{- end }}

{{/*
Create chart name and version as used by the chart label.
*/}}
{{- define "httpd.chart" -}}
{{- printf "%s-%s" .Chart.Name .Chart.Version | replace "+" "_" | trunc 63 | trimSuffix "-" }}
{{- end }}

{{/*
Common labels
*/}}
{{- define "httpd.labels" -}}
helm.sh/chart: {{ include "httpd.chart" . }}
{{ include "httpd.selectorLabels" . }}
{{- if .Chart.AppVersion }}
app.kubernetes.io/version: {{ .Chart.AppVersion | quote }}
{{- end }}
app.kubernetes.io/managed-by: {{ .Release.Service }}
{{- end }}

{{/*
Selector labels
*/}}
{{- define "httpd.selectorLabels" -}}
app.kubernetes.io/name: {{ include "httpd.name" . }}
app.kubernetes.io/instance: {{ .Release.Name }}
{{- end }}

{{/*
Additional pod selector labels
*/}}
{{- define "httpd.additionalPodLabels" -}}
{{- range $key, $value := .Values.httpd.config.files }}
{{ $key | replace "." "-" }}-sha: {{ sha256sum $value | substr 0 31 }}
{{- end }}
{{- range $key, $value := .Values.httpd.vHosts.defaultHosts }}
{{ $key | replace "." "-" }}-sha: {{ sha256sum $value | substr 0 31 }}
{{- end }}
{{- range $key, $value := .Values.httpd.vHosts.additionalHosts }}
{{ $key | replace "." "-" }}-sha: {{ sha256sum $value | substr 0 31 }}
{{- end }}
{{- end }}

{{/*
Create the name of the service account to use
*/}}
{{- define "httpd.serviceAccountName" -}}
{{- if .Values.serviceAccount.create }}
{{- default (include "httpd.fullname" .) .Values.serviceAccount.name }}
{{- else }}
{{- default "default" .Values.serviceAccount.name }}
{{- end }}
{{- end }}
